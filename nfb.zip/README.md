# Project anyar cuy :v

### IMPORTANT (HARAP DIBACA !!!)

```txt
Ihhh .... tolong yaaa ...
jelek - jelek gini ini script juga coding standard make
PSR2 loh ....
akika aja ampe bikin `phpcs.xml` ... pusiiiiing deh kepala eikee...
emangnye itu file buat apaan?
ih jijay deh kalo yey yey tara make `phpcbf` mending yey sanaaa !!!
Pulang ke kandang kambing .. ihhhh

Kalo tara coding standard, emangnyaa eike cowok apakaahhh ...

```
Salam Es Teh 

`^ salam es teh diatas gak usah dianggep yang nulis rada sakit`

#### Sahur mblo, jomblo wayahe sahur iki :v




### PENTING JUGA

```txt
This Repository is gawe dolanan and then gak usah kakean protes!!
When kowe still protes tak uppercut opo need tak cipok mubeng?
Lek need kowe yo must contribute nang this repository!

OK nyet? Monyet?
```


RUMANGSAMU AKU PENGEN TENAR NGONOA?
TENAR KOYO ARTIS NGONOA?!

LOH IYO MES TAH TIII TIII!!! ARTIS KOK!!!?!
TERKENAAAALLL BAYARANE BER-DIGIT DIGIT KOYO KALKULATOR CASIO SENG :

6/2(2+1) = 1

LAH LEK SEMARPON ITUNGANE NGENE!!!

6/2(2+1) = 9

![img_20170527_005743](https://cloud.githubusercontent.com/assets/26004054/26506747/c8be1534-4277-11e7-9570-f620921f5120.jpg)



AKU NGONO GAK MIKIRI NGONO'an TIMBANG GENDENG NGANGGUR!!!

ARTIS NGONO BAYARANE GEDE!!
LAH SOPO SENG GAK GELEM GEDE!?
AKU NGONO GELEM BAYARAN DUWIT DUDU MEK GEDE?!

GEDE ISO AE :

1. DIBAYAR SAMBAT'e GEDE!!!
2. DIBAYAR ALASAN'e GEDE!!!
3. DIBAYAR KIMCIL SENG GEDE!!! (anu'e GEDE!!)
4. DIBAYAR NYICIL GEDE WEKTUNE!!!

RUMANGSAMU AKU KONGKON MANGAN SAMBATAN TA?


MANGKANE WES TALAH!!!
GAK USAH KAKEAN PECETOT !!!?!