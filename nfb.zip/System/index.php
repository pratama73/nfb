<?php
/**
*
*	Silence is golden
*
*/
